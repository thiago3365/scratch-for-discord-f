module.exports = {
    presets: [
        "@vue/app",
    ],
    "sourceType": "unambiguous"
}
