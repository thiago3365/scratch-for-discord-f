import "./newline";
import "./starts-with";
import "./includes";
import "./replace.js";