import "./bot_ping";
import "./bot_server_count";
import "./login";
import "./on_connected";
import "./set_bot_game";
